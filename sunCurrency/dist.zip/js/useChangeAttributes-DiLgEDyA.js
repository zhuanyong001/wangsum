function l(t,n=2){const e=parseFloat(t);return{color:()=>e<0?"#EB3938":"#1FBB85",sign:()=>e<0?"-":"+",replaceFu:(o,u=1)=>Math.abs(parseFloat(o)).toFixed(n)}}export{l as u};
